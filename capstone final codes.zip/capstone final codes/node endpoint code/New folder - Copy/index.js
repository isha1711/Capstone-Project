const express = require('express');
const mysql = require('mysql2');
const cors = require('cors'); // Import cors module
const multer = require('multer');
const up = multer({ dest: 'uploads/'})
const app = express();
const path = require('path');
const port = 3000;
app.use(cors());
app.use(express.json()); // Middleware to parse JSON bodies



// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'capstone'
});

// Test connection
connection.connect(error => {
  if (error) throw error;
  console.log('Successfully connected to the database.');
});

// register api
// Route to fetch data
app.get('/data', (req, res) => {
  connection.query('SELECT * FROM register', (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

// Route to add record
app.post('/addregister', (req, res) => {
  // console.log(req.body)
  const { first, last, email, username, password } = req.body;
  const sql = 'INSERT INTO register (first, last, email, username, password) VALUES (?, ?, ?, ?, ?)';
  connection.query(sql, [first, last, email, username, password], (error, result) => {
    if (error) {
      res.status(500).json({ error: 'Error adding record' });
    } else {
      res.status(200).json({ message: 'Record added successfully' });
    }
  });
});

// contact us api 
app.get('/contactus', (req, res) => {
  // SQL query
  const sql = "SELECT `id`, `first_name`, `last_name`, `phone` FROM `contactus`";

  // Execute the query
  connection.query(sql, (err, results) => {
    if (err) {
      throw err;
    }
    // Send the results as JSON
    res.json(results);
  });
});

// app conn contactus

app.post('/addContact', (req, res) => {
  const { firstName, lastName,  phone } = req.body;

  // SQL query to insert data into the contactus table
  const sql = `INSERT INTO contactus (first_name, last_name, phone) VALUES (?, ?, ?)`;
  const values = [firstName, lastName, phone];

  connection.query(sql, values, (err, result) => {
    if (err) {
      res.status(500).send('Error adding contact');
     // throw err;
    } else {
   // console.log('Contact added successfully');
    res.status(200).send('Contact added successfully');
    }
  });
});

//contact form
app.get('/contacts', (req, res) => {
  const sql = 'SELECT `c_id`, `Email`, `Subject`, `Message` FROM `contact`';
  connection.query(sql, (err, result) => {
    if (err) {
      console.error('Error fetching contacts:', err);
      res.status(500).json({ error: 'Internal server error' });
    } else {
      res.json(result);
    }
  });
});

app.post('/contacts', (req, res) => {
  const {  email, subject, message } = req.body;

  // Insert contact information into database
  const sql = 'INSERT INTO contact ( Email, Subject, Message) VALUES (?, ?, ?)';
  connection.query(sql, [ email, subject, message], (err, result) => {
    if (err) {
      console.error('Error adding contact:', err);
      res.status(500).json({ error: 'Internal server error' });
    } else {
      console.log('Contact added successfully');
      res.status(200).json({ message: 'Contact added successfully' });
    }
  });
});

// appointment get code 
app.get('/appointments', (req, res) => {
  connection.query('SELECT * FROM appointment', (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

// add appointments

app.post('/addappointments', (req, res) => {
  const { name, date, time, status } = req.body;

  // Insert appointment into the database
  const query = 'INSERT INTO appointment (name, date, time, status) VALUES (?, ?, ?, ?)';
  connection.query(query, [name, date, time, status], (err, result) => {
    if (err) {
      console.error('Error adding appointment:', err);
      res.status(500).json({ error: 'Error adding appointment' });
      return;
    }
    console.log('Appointment added:', result);
    res.status(201).json({ message: 'Appointment added successfully' });
    
  });
});

// get feedback 
app.get('/ratings', (req, res) => {
  connection.query('SELECT * FROM rating', (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

// add feedback


app.post('/api/feedback', (req, res) => {
  const { name, stars, message } = req.body;

  if (!name || !stars || !message) {
    return res.status(400).json({ error: 'Please provide name, stars, and message.' });
  }

  const sql = 'INSERT INTO rating (name, stars, message) VALUES (?, ?, ?)';
  const values = [name, stars, message];

  connection.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error adding feedback: ' + err.message);
      return res.status(500).json({ error: 'Failed to add feedback.' });
    }
    console.log('Feedback added successfully.');
    res.status(200).json({ message: 'Feedback added successfully.' });
  });
});

// get upload 
app.get('/api/uploads', (req, res) => {
  const query = 'SELECT u_id, name, file, created_at FROM upload';
  connection.query(query, (error, results) => {
    if (error) {
      console.error('Error executing MySQL query:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.json(results);
  });
});

// add upload
// Multer configuration for handling file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); // Specify the directory where files will be uploaded
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); // Use the original file name for storing
  }
});

const upload = multer({ storage });

app.post('/uploadfile', upload.single('file'), (req, res) => {
  // Check if file exists in the request
  if (!req.file) {
    return res.status(400).send('No file uploaded');
  }

  // Insert uploaded file details into the database
  const {  filename } = req.file;
  // const createdAt = new Date().toISOString(); // Use current timestamp for created_at

  
  const sql = 'INSERT INTO upload (file) VALUES (?)';
  connection.query(sql, [filename], (err, result) => {
    if (err) {
      console.error('Error uploading file:', err);
      return res.status(500).send('Error uploading file');
    }
    console.log('File uploaded successfully');
    res.status(200).send('File uploaded successfully');
  });
});


// get service
app.get('/services', (req, res) => {
  connection.query('SELECT * FROM service', (error, results) => {
    if (error) throw error;
    res.json(results);
  });
});

// get news 

app.get('/newsupdates', (req, res) => {
  const query = 'SELECT  `title`, `description` FROM `newsupdate`';
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.json(results);
  });
});

// get download 
app.get('/download', (req, res) => {
  const query = 'SELECT name, file FROM download';
  connection.query(query, (error, results) => {
    if (error) {
      console.error('Error executing MySQL query:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.json(results);
  });
});
app.get('/download1/:fileName', (req, res) => {
  const fileName = req.params.fileName;

  // Check if the file exists in the 'upload' folder
  const filePath = path.join(__dirname, 'uploads', fileName);
  res.download(filePath, (err) => {
    if (err) {
      console.error('Error downloading file:', err);
      res.status(500).send('Error downloading file');
    }
  });
});

app.get('/download/:fileName', (req, res) => {
  const fileName = req.params.fileName;

  // Retrieve file metadata from MySQL database
  const sql = 'SELECT file FROM download WHERE name = ?';
  connection.query(sql, [fileName], (err, result) => {
    if (err) {
      console.error('Error fetching file from database:', err);
      res.status(500).send('Error fetching file');
    } else if (result.length === 0) {
      res.status(404).send('File not found');
    } else {
      // Stream file data back to client
      const fileData = result[0].file;
      const fileStream = fs.createReadStream(fileData);
      fileStream.pipe(res);
    }
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
