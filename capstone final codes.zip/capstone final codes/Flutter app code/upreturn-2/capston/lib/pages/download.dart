import 'package:capston/pages/contactus.dart';
import 'package:flutter/material.dart';

import 'package:capston/pages/aboutus.dart';
import 'package:capston/pages/appointment.dart';
import 'package:capston/pages/calculate.dart';
import 'package:capston/pages/services.dart';
import 'package:capston/pages/settings.dart';
import 'package:capston/pages/upload.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';




class Download extends StatefulWidget {
  const Download({Key? key}) : super(key: key);

  @override
  _DownloadState createState() => _DownloadState();
}

class _DownloadState extends State<Download> {
  List<Map<String, dynamic>> downloads = [];

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse('http://localhost:3000/download'));
    if (response.statusCode == 200) {
      final List<dynamic> responseData = jsonDecode(response.body);
      setState(() {
        downloads = responseData.cast<Map<String, dynamic>>();
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to fetch data'),
        ),
      );
    }
  }

 Future<void> downloadFile(String fileData) async {
  try{
  final response = await http.get(Uri.parse('http://localhost:3000/download1/$fileData'));
 if (response.statusCode == 200) {
        setState(() {
          fileData = response.body; // Store the file data in the fileData variable
        });
      } else {
        
        throw Exception('Failed to fetch file data');
      }
    } catch (error) {
      print('Error fetching file data: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to fetch file data'),
        ),
      );
    }
  }


      

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(100),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(35),
              bottomLeft: Radius.circular(35),
            ),
            color: Color(0xFF191d46),
          ),
          child: AppBar(
            shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.vertical(bottom: Radius.circular(50))),
            backgroundColor: Color(0xFF191d46),
            title: Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: const EdgeInsets.only(top: 3, bottom: 0, right: 16.0),
                child: Text(
                  'Download File',
                  style: TextStyle(
                    fontSize: 55,
                    fontFamily: 'JockeyOne',
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            iconTheme: IconThemeData(color: Colors.white,size: 35), // Drawer icon color
          ),
        ),
      ),
       drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Color(0xFF191d46), // Blue hex color for drawer header
              ),
              child: Text(
                'Up Return',
                style: TextStyle(
                  fontFamily: "Jomhuria",
                  fontSize: 90,
                  color: Color(0xFFebf3ff),
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.calculate),
              title: Text('Gst Calculator'),
              onTap: () {Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Calc(),

                ),
              );},
            ),
            ListTile(
              leading: Icon(Icons.file_upload),
              title: Text('Upload Documents'),
              onTap: () {Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => UploadPdf(),

                ),
              );},
            ),
            ListTile(
              leading: Icon(Icons.file_download),
              title: Text('Download Documents'),
              onTap: () {
                 Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Download(),

                ),
              );
              },
            ),
            ListTile(
              leading: Icon(Icons.event),
              title: Text('Appointment Booking'),
              onTap: () {Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AppointmentBooking(),

                ),
              );},
            ),
            ListTile(
              leading: Icon(Icons.widgets),
              title: Text('Services'),
              onTap: () {Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Services(),

                ),
              );},
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
              onTap: () {Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Settings(),

                ),
              );},
            ),
            ListTile(
              leading: Icon(Icons.info),
              title: Text('About Us'),
              onTap: () {Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AboutUs(),

                ),
              );},
            ),
            ListTile(
              leading: Icon(Icons.contact_mail),
              title: Text('Contact Us'),
              onTap: () {
                 Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ContactUs(),

                ),
              );
              },
            ),
          
          ],
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 20,),
          ElevatedButton(
            onPressed: fetchData,
            style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(Color.fromARGB(255, 69, 120, 228)), // Change this to the desired color
  ),
            child: Text('Update Data',style: TextStyle(color: Colors.white),),
            
          ),
          Expanded(
            child: ListView.builder(
              itemCount: downloads.length,
              itemBuilder: (context, index) {
                final download = downloads[index];
                return ListTile(
                  title: Text(download['name']),
                  subtitle: Text(download['file']),
                  trailing: ElevatedButton(
                    onPressed: () => downloadFile(download['file']),
                    style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(Color.fromARGB(255, 69, 120, 228)), // Change this to the desired color
  ),// Change this to the desired color
  
                    child: Text('Download',style: TextStyle(color: Colors.white),),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
