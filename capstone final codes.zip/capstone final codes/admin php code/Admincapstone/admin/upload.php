<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>


<!-- insert Modal -->
<div class="modal fade" id="insertdata" tabindex="-1" aria-labelledby="insertdataLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="insertdataLabel">Upload File Here</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="upadd.php" method="POST" enctype="multipart/form-data">
      <div class="modal-body">
       <div class="form-group mb-3">
        <label for="">Enter File Name:</label>
        <input type="text" name="name" class="form-control" placeholder="enter name">
       </div>
       <div class="form-group mb-3">
        <label for="">Upload File:</label>
        <input type="file" name="file" class="form-control hover" placeholder="">
       </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary mb-6" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="upload_btn" class="btn btn-primary mb-6">Upload</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- <?php
if (isset ($_SESSION['status']) && $_SESSION['status'] != '') {

    ?>
             <?php echo $_SESSION['status']; ?>
                   
                <?php
    //unset($_SESSION['status']);
}
?> -->
<div class="card mt-5">
    <div class="card-header">
        <h4>

            Upload Necessary Files
            <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#insertdata">
               Upload Doc
            </button>
            <!-- <a href="newsinsert.php" class="btn btn-primary float-end">Upload Doc</a> -->

        </h4>
        <div class="card-body">

        </div>
    </div>
</div>
</div>
</div>
</div>
<!-- </div>
</div> -->

<?php include ('includes/footer.php'); ?>