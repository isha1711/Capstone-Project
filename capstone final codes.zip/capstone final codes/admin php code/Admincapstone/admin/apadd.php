<?php
session_start();
$connect = mysqli_connect("localhost","root","","capstone");

if(isset($_POST['save']))
{

    $name = $_POST['name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $status = $_POST['status'];

    $insert_query = "INSERT INTO appointment(name,date,time,status) VALUES ('$name','$date','$time','$status') ";
    $insert_query_run = mysqli_query($connect,$insert_query );

    if($insert_query_run)
    {
        $_SESSION['status'] = "DATA INSERTED SUCESSFULLY";
        $_SESSION['status_code'] = "success";
        header('location: appointment.php');
    }
    else{
        $_SESSION['status'] = "DATA NOT INSERTED SUCESSFULLY";
        $_SESSION['status_code'] = "error";
        header('location: apinsert.php');
    }

}

if(isset($_POST['update']))
{   
    $id =$_POST['a_id'];
    $name = $_POST['name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $status = $_POST['status'];
    
    $update_query ="UPDATE appointment SET name='$name', date='$date', time='$time', status='$status'WHERE a_id='$id'";
    $update_query_run = mysqli_query($connect, $update_query);

    if($update_query_run)
    {
        $_SESSION['status'] = "DATA UPDATED SUCESSFULLY";
        $_SESSION['status_code'] = "success";
        header('location: appointment.php');
    }
    else{
        $_SESSION['status'] = "DATA NOT UPDATED SUCESSFULLY";
        $_SESSION['status_code'] = "error";
        header('location: apinsert.php');
    }
}
if(isset($_POST['delete']))
{
    $id =$_POST['a_id'];
    $delete_query = "DELETE FROM appointment WHERE a_id= '$id'";
    $delete_query_run = mysqli_query($connect, $delete_query);

    if($delete_query_run)
    {
        $_SESSION['status'] = "DATA DELETED SUCESSFULLY";
        $_SESSION['status_code'] = "success";
        header('location: appointment.php');
    }
    else{
        $_SESSION['status'] = "DATA NOT DELETED ";
        $_SESSION['status_code'] = "success";
        header('location: appointment.php');
}
}
?>