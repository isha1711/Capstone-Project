<?php
session_start();
$connection = mysqli_connect("localhost","root","","capstone");

if(isset($_POST['save_btn']))
{

    $title = $_POST['title'];
    $detail = $_POST['description'];

    $insert_query = "INSERT INTO newsupdate(title,description) VALUES ('$title','$detail') ";
    $insert_query_run = mysqli_query($connection,$insert_query );

    if($insert_query_run)
    {
        $_SESSION['status'] = "DATA INSERTED SUCESSFULLY";
        $_SESSION['status_code'] = "success";
        header('location: news.php');
    }
    else{
        $_SESSION['status'] = "DATA NOT INSERTED SUCESSFULLY";
        $_SESSION['status_code'] = "error";
        header('location: newsinsert.php');
    }

}

?>