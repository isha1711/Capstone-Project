<?php
session_start();
$connection = mysqli_connect("localhost","root","","capstone");

if(isset($_POST['add_btn']))
{
    $id = $_POST['s_id'];
    $name = $_POST['Name'];
  

    $insert_query = "INSERT INTO service(s_id,Name) VALUES ('$id','$name') ";
    $insert_query_run = mysqli_query($connection,$insert_query );

    if($insert_query_run)
    {
        $_SESSION['status'] = "SERVICE ADDED";
        $_SESSION['status_code'] = "success";
        header('location: service.php');
    }
    else{
        $_SESSION['status'] = "SERVICE NOT INSERTED";
        $_SESSION['status_code'] = "error";
        header('location: serviceinsert.php');
    }

}

?>