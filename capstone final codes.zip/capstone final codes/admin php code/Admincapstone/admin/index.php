<?php include ('includes/header.php'); ?>

<div class="container-fluid py-4">
    <div class="row min-vh-80 h-100">
        <div class="col-12">

                <div class="row">
                    <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
                        <div class="card">
                            <div class="card-header p-3 pt-2">
                                <div
                                    class="icon icon-lg icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-xl mt-n4 position-absolute">
                                    <i class="material-icons opacity-10">person</i>
                                </div>
                                <div class="text-end pt-1">
                                    <p class="text-sm mb-0 text-capitalize">Total Users</p>
                                    <h4 class="mb-0">281</h4>
                                </div>
                            </div>

                            <hr class="dark horizontal my-0">
                            <div class="card-footer p-3">
                                <p class="mb-0"><span class="text-success text-sm font-weight-bolder">+55%
                                    </span>than last week</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
                    <div class="card">
                        <div class="card-header p-3 pt-2">
                            <div
                                class="icon icon-lg icon-shape bg-gradient-primary shadow-primary shadow text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">leaderboard</i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize">New Users</p>
                                <h4 class="mb-0">100</h4>
                            </div>
                        </div>

                        <hr class="dark horizontal my-0">
                        <div class="card-footer p-3">
                            <p class="mb-0"><span class="text-success text-sm font-weight-bolder">+3%
                                </span>than last month</p>
                        </div>
                    </div>
                    </div>

                   

                    <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
                    <div class="card ">
                        <div class="card-header p-3 pt-2 bg-transparent">
                            <div
                                class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">calendar_today</i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize ">Booked Appointments</p>
                                <h4 class="mb-0 ">10</h4>
                            </div>
                        </div>

                        <hr class="horizontal my-0 dark">
                        <div class="card-footer p-3">
                            <p class="mb-0 ">Just updated</p>
                        </div>
                    </div>
                    </div>
                    

                    <div class="col-lg-5 col-sm-5 mt-sm-0 mt-4">

                    </div>
                </div>

                

<div class="container-fluid py-4">
    <div class="row min-vh-80 h-100">
        <div class="col-12">
        <?php
//database connection details

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "capstone";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);


if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

//Fetch the uploaded files from the database

$sql = "SELECT *FROM register ORDER BY id DESC";
$result = $conn->query($sql);


?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

    <div class="card mt-5">
        <div class="card-header">
            <h4>

              Registered User

            </h4>
            <div class="card-body">
                <table class="table table-success table-hover text-center">
                    <thead class="table-dark">
                        <tr>
                           
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Password</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <?php
                        // Display the uploaded files and download links
                        if (!$result) {
                            die('Invail Query:'. $conn->error);
                        }
                            while ($row = $result->fetch_assoc()) {
                               echo "<tr>
                               
                               <td>" . $row["first"]."</td>
                               <td>" . $row["last"]."</td>
                               <td>" . $row["email"]."</td>
                               <td>" . $row["username"]."</td>
                               <td>" . $row["password"]."</td>
                               </tr>";
                        
                            }
                    ?>
                            <?php
                        
                        ?>
                    </tbody>
                </table>
            </div>
          

        
</body>

</html>

<?php
$conn->close();
?>
<?php include ('includes/footer.php'); ?>
          
        
    </div>
</div>
</div>




                
        </div>
    </div>
</div>
</div>

<!-- <?php include ('includes/footer.php'); ?> -->