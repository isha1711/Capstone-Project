<?php
session_start();
$connection = mysqli_connect("localhost","root","","capstone");

if(isset($_POST['login_btn']))
{

    $username = $_POST['username'];
    $password = $_POST['password'];

    $insert_query = "SELECT * FROM login WHERE username= '$username' AND password= '$password' ";
    $insert_query_run = mysqli_query($connection,$insert_query );

    if(mysqli_num_rows($insert_query_run)>0)
    {
        echo"Login Successfull";
        header('location: index.php');
    }
    else{
       echo 'Login Failed';
       header('location: login.php');
    }

}

?>