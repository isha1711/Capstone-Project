<?php include ('includes/header.php'); ?>

<div class="container-fluid py-4">
    <div class="row min-vh-80 h-100">
        <div class="col-12">


            <div class="card">
                <div class="card-header">
                    <h4>
                        Insert Data For Appointments
                        <a href="appointment.php" class="btn btn-info float-end">Back</a>
                        <!-- <a href="newsinsert.php" class="btn btn-primary float-end">Insert Draft</a> -->
                    </h4>
                </div>
                <div class="card-body">

                    <form action="apadd.php" method="POST">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="exampleInputEmail1"
                                required>
                           
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Date</label>
                            <input type="text" class="form-control" name="date" id="exampleInputEmail1"
                                required>
                           
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Time</label>
                            <input type="text" class="form-control" name="time" id="exampleInputEmail1"
                                required>
                           
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Status</label>
                            <input type="text" class="form-control" name="status" id="exampleInputEmail1"
                                required>
                           
                        </div>
                        <div class="mb-3">
                                <button type="submit" name="save" class="btn btn-primary">Save</button>
                        </div>
                    
                       
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- </div>
</div> -->

    <?php include ('includes/footer.php'); ?>