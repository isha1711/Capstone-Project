<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>



          
            <!-- <?php
            if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
               
                ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>Hey!</strong> <?php  echo $_SESSION['status'];?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                //unset($_SESSION['status']);
            }
            ?> -->
            <div class="card mt-5">
                <div class="card-header">
                    <h4>

                        Added Services
                        <a href="serviceinsert.php" class="btn btn-primary float-end">Add New</a>

                    </h4>
                    <div class="card-body">
                    <table class="table text-center">
  <thead class="table-dark">
    <tr>
     
      <th scope="col">Name</th>
      
      
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <?php 
   $fetch_query ="SELECT * FROM service";
   $fetch_query_run = mysqli_query($connection,$fetch_query);

   if(mysqli_num_rows($fetch_query_run) > 0)
   {
     foreach($fetch_query_run as $row)
     {
      ?>
      <tr>
      
      
      <td><?php echo $row['Name']; ?></td>
      
      
    </tr>
      <?php
     }
   }
    else
    {
      ?>
      <tr>
      <td colspan="5">No record found!</td>
    </tr>

    <?php
    }
    ?>
    
  </tbody>
</table>
          </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- </div>
</div> -->

<?php include ('includes/footer.php'); ?>