<?php
//database connection details

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "capstone";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);


if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

//Fetch the uploaded files from the database

$sql = "SELECT *FROM contactus";
$resul = "SELECT *FROM contact";
$res = $conn->query($resul);
$result = $conn->query($sql);


?>
<?php include ('includes/header.php'); ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <title>Uploaded files</title> -->
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> -->
</head>

<body>

    <div class="card mt-5">
        <div class="card-header">
            <h4>

               Contacted User

            </h4>
            <div class="card-body">
                <table class="table table-success table-hover text-center">
                    <thead class="table-dark">
                        <tr>
                           
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Phone No</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <?php
                        // Display the uploaded files and download links
                        if (!$result) {
                            die('Invail Query:'. $conn->error);
                        }
                            while ($row = $result->fetch_assoc()) {
                               echo "<tr>
                               <td>" . $row["first_name"]."</td>
                               <td>" . $row["last_name"]."</td>
                               <td>" . $row["phone"]."</td>
                               </tr>";
                        
                            }
                    ?>
                            <?php
                        
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- <div class="card-body">
                <table class="table table-success table-hover">
                    <thead class="table-dark">
                        <tr>
                           
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <?php
                        // Display the uploaded files and download links
                        if (!$result) {
                            die('Invail Query:'. $conn->error);
                        }
                            while ($row = $result->fetch_assoc()) {
                               echo "<tr>
                               <td>" . $row["Email"]."</td>
                               <td>" . $row["Subject"]."</td>
                               <td>" . $row["Message"]."</td>
                               </tr>";
                        
                            }
                    ?>
                            <?php
                        
                        ?>
                    </tbody>
                </table>
            </div> -->

        
</body>
<div class="card-body">
                <table class="table table-success table-hover text-center">
                    <thead class="table-dark">
                        <tr>
                           
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider text-center">
                        <?php
                        // Display the uploaded files and download links
                        if (!$res) {
                            die('Invail Query:'. $conn->error);
                        }
                            while ($row = $res->fetch_assoc()) {
                               echo "<tr>
                               <td>" . $row["Email"]."</td>
                               <td>" . $row["Subject"]."</td>
                               <td>" . $row["Message"]."</td>
                               </tr>";
                        
                            }
                    ?>
                            <?php
                        
                        ?>
                    </tbody>
                </table>
            </div>
</html>

<?php
$conn->close();
?>
<?php include ('includes/footer.php'); ?>