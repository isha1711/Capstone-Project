<?php
session_start();
$connection = mysqli_connect("localhost","root","","capstone");

if(isset($_POST['upload_btn']))
{

    $name = $_POST['name'];
    $file = $_FILES['file']['name'];

    $insert_query = "INSERT INTO download(name,file) VALUES ('$name','$file') ";
    $insert_query_run = mysqli_query($connection,$insert_query );

    if($insert_query_run)
    {
        move_uploaded_file($_FILES["file"]["tmp_name"],"uploads/".$_FILES['file']['name']);
        $_SESSION['status'] = "FILE INSERTED SUCESSFULLY";
        $_SESSION['status_code'] = "success";
        header('location: upload.php');
    }
    else{
        $_SESSION['status'] = "FILE NOT INSERTED SUCESSFULLY";
        $_SESSION['status_code'] = "error";
        header('location: upload.php');
    }

}

?>