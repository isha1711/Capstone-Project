<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>



          
            <!-- <?php
            if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
               
                ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>Hey!</strong> <?php  echo $_SESSION['status'];?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                //unset($_SESSION['status']);
            }
            ?> -->
            <div class="card mt-5">
                <div class="card-header">
                    <h4>

                        Insert Data for appointments
                        <a href="apinsert.php" class="btn btn-primary float-end">Insert Draft</a>

                    </h4>
                    <div class="card-body">
                    <table class="table table-success table-striped table-hover">
  <thead class="table-dark">
    <tr>
      
      <th scope="col">Name</th>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
      <th scope="col">Status</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
      
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <?php 
   $fetch_query ="SELECT * FROM appointment ORDER BY a_id DESC";
   $fetch_query_run = mysqli_query($connect,$fetch_query);

   if(mysqli_num_rows($fetch_query_run) > 0)
   {
     foreach($fetch_query_run as $row)
     {
      ?>
      <tr>
      
      
      <td><?php echo $row['name']; ?></td>
      <td><?php echo $row['date']; ?></td>
      <td><?php echo $row['time']; ?></td>
      <td><?php echo $row['status']; ?></td>
      <td>
        <a href="edit.php?a_id=<?php echo $row['a_id']; ?>" class=" btn btn-success "><i class="material-icons center opacity-10">edit_note</i></a>

        <!-- <a href="#" class=" btn btn-info"><i class="material-icons center opacity-10">delete</i></a> -->
        
      </td>
      <td>
        <form action="apadd.php" method="post">
        
          <input type="hidden" class="form-control" name="a_id" value="<?php echo $row['a_id']; ?>">
          <!-- <button type="submit" name="delete" class="button button2"><i class="material-icons center opacity-10">delete</i></button> -->
          <button type="submit" name="delete" class="btn btn-info material-icons">delete</button>
          </form>

        <!-- <a href="edit.php?a_id=<?php echo $row['a_id']; ?>" class=" btn btn-success"><i class="material-icons center opacity-10">edit_note</i></a> -->

        
      </td>
      
    </tr>
      <?php
     }
   }
    else
    {
      ?>
      <tr>
      <td colspan="7">No record found!</td>
    </tr>

    <?php
    }
    ?>
    
  </tbody>
</table>
          </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- </div>
</div> -->

<?php include ('includes/footer.php'); ?>