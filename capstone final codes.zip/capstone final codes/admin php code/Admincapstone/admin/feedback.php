<?php include ('dbconfig/dbconfig.php'); ?>
<?php include ('includes/header.php'); ?>

<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <!-- <link rel="stylesheet" type="text/css" href="material-dashboard.css"> -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
          
<?php include 'mysqli.php'; ?>
            <div class="card mt-5">
                <div class="card-header">
                    <h3>

                        Feedback
                        <!-- <a href="newsinsert.php" class="btn btn-primary float-end">Insert Draft</a> -->

                    </h3>
                    <div class="card-body">
                    <?php 
                
                $query="SELECT * FROM `rating`ORDER BY f_id DESC";

                $result=mysqli_query($conn , $query);

                while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)) 
                {       
                
                ?>
                  <div class="thumb-wrapper">
                   

                     <div class="thumb-content">
                      <div class="box mb-5">
                       <h3><?php echo $row['name'];?></h3>   
                       <h5><?php echo $row['message'];?></h5>   
                         <div class="star-rating">
                           <ul class="list-inline">
                            <?php 
                             
                             $start=1;
                             while ($start <= 5) 
                             {
                             	if ($row['stars'] < $start) 
                                {
                                 ?>
                                 <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                                 <?php
                             	}else{
                             	 ?>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                             	 <?php
                             	}

                             	$start++;
                             }
                            ?>                
                          </ul>
                        </div>
                      </div>
                        <?php
                }
                ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- </div>
</div> -->

</body>
</html>

<?php include ('includes/footer.php'); ?>